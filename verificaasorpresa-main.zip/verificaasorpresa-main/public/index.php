<?php

declare(strict_types=1);

// Include il bootstrap con la definizione completa dell'app.
require __DIR__ . '/../bootstrap/app.php';

// Esegue l'applicazione Slim.
$app->run();
